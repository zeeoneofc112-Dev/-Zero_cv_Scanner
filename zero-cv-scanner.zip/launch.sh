#!/bin/bash
cd "$(dirname "$0")"
python zero_cv_scanner.py
